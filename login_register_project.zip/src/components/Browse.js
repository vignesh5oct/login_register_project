import React from 'react'
import Home from './Home'

const Browse = () => {
  return (
    <div>
      <Home/>
    </div>
  )
}

export default Browse
